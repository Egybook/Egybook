EgyBook - Implemented Fixes

Updates in this package:
- Post reactions modal loads real rows from Supabase post_reactions.
- Friend request table migration is included in EGYBOOK_FRIEND_REQUESTS_MIGRATION.sql.
- Profile navigation from comment names/avatars now resolves the commenter by auth user ID to profiles.username, instead of guessing a username from the display name.
- Cloud comments load their author username and avatar from profiles, when visible under the active RLS policies.
- Public profile loading resets stale profile labels while loading and ignores late responses for a different profile.
- Cloud posts carry the author's actual username in their DOM data.

Checks performed:
- script.js passed `node --check`.

Not verified here:
- Live Supabase requests, RLS behavior, and deployment behavior.
- End-to-end friendship acceptance/rejection and displaying friends' posts.
- Realtime configuration on the Supabase project.

After replacing files, deploy the updated files to the site. Run the SQL migration only if it has not already been applied. Since the friend_requests table was confirmed visible in Supabase, do not rerun that migration without reviewing whether it is safe/idempotent for the current database.
