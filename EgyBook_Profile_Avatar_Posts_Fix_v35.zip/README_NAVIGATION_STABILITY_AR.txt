EgyBook — Navigation/Overlay Stability Fix
==========================================
Updated:
- script.js: closing the comments overlay on a post route keeps the user on that post instead of unexpectedly pushing them to Home.
- Browser Back dismisses open comments/reaction overlays before resolving the destination route.
- Escape dismisses the active overlay (image viewer, comments, reactions, or another non-auth modal).

Validation:
- `node --check script.js` passed.
- No live GitHub Pages/Supabase browser test was performed.

Important:
This is a focused navigation stability fix, not proof of a site-wide performance optimization.
A reliable performance pass needs profiling on the live app to identify slow queries, repeated render work,
large media, and long-running event handlers. Do not claim all pages are faster until those checks are run.
