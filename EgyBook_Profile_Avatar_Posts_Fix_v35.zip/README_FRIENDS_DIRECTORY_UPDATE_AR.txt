EgyBook — Friends Directory Update

Implemented in this package:
- Bottom/top navigation "الأصدقاء" now opens a dedicated friends directory instead of the placeholder friends-feed toast.
- Directory has tabs for current friends, incoming friend requests, and suggested profiles.
- Incoming requests can be accepted or rejected using the existing friend_requests table.
- Accepted friend relationships are displayed in the directory.
- Each profile page now has an "الأصدقاء" section showing up to 8 accepted friends; selecting a friend opens that person's profile.
- Profile friends count is populated from accepted relationships rather than a hard-coded zero.
- Added responsive dark/neon styling for the directory and profile friends cards.
- script.js passed `node --check`.

Important backend requirements:
- The directory reads accepted rows from public.friend_requests where status='accepted'.
- Incoming requests are read from public.friend_requests where receiver_id is the signed-in user and status='pending'.
- Public profile cards are loaded from public.profiles (id, full_name, username, avatar_url).
- The current friend list will show only relationships represented in Supabase as accepted friend_requests rows. If an older friendship exists only in local/browser state and not in this table, it must be migrated/added to the database before it can appear for all accounts.
- The user must deploy index.html, styles.css, and script.js together.
- Do not rerun SQL migrations blindly. Check Supabase first: the friend_requests table migration is EGYBOOK_FRIEND_REQUESTS_MIGRATION.sql. Run it only if the table/policies are not already installed. EGYBOOK_PROFILE_RELATIONSHIPS_MIGRATION.sql is only needed for follow functionality, not for the friend directory itself.
- Live Supabase/RLS and production browser behavior were not tested in this environment. Validate with two test accounts: send request, accept request, verify both profiles show each other, and verify requests are only visible to participants.


Performance refinement (2026-10-24):
- Profile post counts no longer switch to an ellipsis while refreshing; existing post cards remain visible during refresh.
- Existing profile posts are preserved if a refresh fails, instead of being replaced by a connection-error placeholder.
- Friends directory now caches the last successful rendered tab per signed-in user and tab, displays it immediately on revisit, and refreshes in the background.
- Profile friends section no longer clears the existing friend cards before refreshing.
- Validation performed here: JavaScript syntax check (`node --check`) passed.
- Not verified against the live Supabase project or production browser. Accurate counts still depend on the deployed schema, RLS policies, and valid `posts` / `friend_requests` data.
