-- EgyBook: fix profile post loading for the owner.
-- Safe additive policy: does not grant users access to other users' private posts.
-- Run in Supabase Dashboard > SQL Editor.

begin;

grant select on table public.posts to authenticated;

alter table public.posts enable row level security;

drop policy if exists "EgyBook owners can read their own posts" on public.posts;
create policy "EgyBook owners can read their own posts"
  on public.posts
  for select
  to authenticated
  using (auth.uid() = user_id);

commit;

notify pgrst, 'reload schema';
