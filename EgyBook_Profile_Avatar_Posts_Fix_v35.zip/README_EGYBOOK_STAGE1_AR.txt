EgyBook Stage 1 update (from V6)
================================

Modified files:
- index.html: removed hard-coded sample posts and sample story cards from the initial HTML.
- script.js: profile badge now checks verified_accounts for the viewed profile instead of hiding the badge; story actions no longer claim demo stories are available.
- styles.css: stabilized profile counts and post-author layout; hides any remaining static non-add story cards.

Important:
- No Supabase schema or data was changed.
- Real post loading remains dependent on the existing Supabase posts query and RLS policies.
- Stories are NOT fully activated by this patch because the current project archive does not establish a verified stories table/schema or upload flow. The fake story cards are removed and the UI now says the feature is not active. A proper stories migration and upload/view flow must be designed against your actual Supabase schema before claiming stories are live.
- Browser/live Supabase behavior was not tested here.
