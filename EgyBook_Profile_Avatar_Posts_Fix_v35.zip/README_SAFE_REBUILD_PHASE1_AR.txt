EgyBook Safe Rebuild Phase 1 (V22)

IMPORTANT
- This is a prepared migration file; it has NOT been run against the user's live Supabase project.
- Take a Supabase backup before running it.
- It intentionally preserves auth.users and public.profiles, and does not delete profile images or any Storage objects.
- It preserves profile_private, user_roles, verified_accounts, verification_requests, verification_settings.
- It deletes demo/social rows from listed social tables, including posts and their comments/reactions, notifications, friend requests, and follows.
- It converts post_reactions.post_id and post_comments.post_id from TEXT to UUID, adds foreign keys to posts, and fixes notification triggers to compare UUID with UUID.
- If any required preflight object is missing or the schema differs, the transaction errors and rolls back.
- Do not run the old EGYBOOK_FIX_REACTION_UUID_TEXT.sql after this migration; its assumptions are superseded by the UUID schema.

How to apply:
1. Supabase Dashboard -> Database backups: create/download a backup first.
2. Open SQL Editor.
3. Copy/run EGYBOOK_SAFE_REBUILD_PHASE1.sql.
4. Confirm success before testing the site.
5. Test login, create a post, react, comment, verify notification, and check that profile avatars/covers remain.
6. If SQL errors, stop and send the exact error; do not run additional migrations blindly.

Scope limitations:
- This phase does not change script.js or styles.css.
- Current frontend still uses posts.media_url/media_type for post media. Do not switch to post_media/media_assets until a separate compatible frontend migration is prepared and tested.
- This phase addresses the UUID/TEXT interaction-trigger mismatch and resets demo/social rows. It does not alone prove homepage freezing is resolved.
